<?php
/**
 * Plugin Name: WP STEP Viewer
 * Description: Upload STEP/STP CAD files and share them via a unique online 3D viewer URL.
 * Version:     1.2.0
 * License:     GPL-2.0+
 * Text Domain: wp-step-viewer
 */

defined( 'ABSPATH' ) || exit;

define( 'WPSV_VERSION',    '1.2.0' );
define( 'WPSV_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPSV_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPSV_UPLOAD_SUBDIR', 'step-files' );

require_once WPSV_PLUGIN_DIR . 'includes/class-roles.php';
require_once WPSV_PLUGIN_DIR . 'includes/class-post-types.php';
require_once WPSV_PLUGIN_DIR . 'includes/class-uploader.php';
require_once WPSV_PLUGIN_DIR . 'includes/class-viewer.php';
require_once WPSV_PLUGIN_DIR . 'includes/class-cleanup.php';
require_once WPSV_PLUGIN_DIR . 'includes/class-admin.php';

register_activation_hook( __FILE__, function () {
    WPSV_Post_Types::register_cpt();
    WPSV_Roles::activate();
    flush_rewrite_rules();
} );

register_deactivation_hook( __FILE__, function () {
    WPSV_Roles::deactivate();
    WPSV_Cleanup::deactivate();
    flush_rewrite_rules();
} );

add_action( 'plugins_loaded', function () {
    WPSV_Post_Types::init();
    WPSV_Uploader::init();
    WPSV_Viewer::init();
    WPSV_Cleanup::init();
    WPSV_Admin::init();
} );
