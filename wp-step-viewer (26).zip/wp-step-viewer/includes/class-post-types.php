<?php
defined( 'ABSPATH' ) || exit;

class WPSV_Post_Types {

    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_cpt' ) );
    }

    public static function register_cpt() {
        register_post_type( 'step_model', array(
            'labels' => array(
                'name'          => 'STEP Models',
                'singular_name' => 'STEP Model',
                'add_new_item'  => 'Upload STEP Model',
                'view_item'     => 'View in 3D',
            ),
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => false,
            'show_in_menu'       => false,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'model' ),
            'capability_type'    => array( 'step_model', 'step_models' ),
            'map_meta_cap'       => true,
            'has_archive'        => false,
            'supports'           => array( 'title' ),
            'show_in_rest'       => false,
        ) );
    }

    public static function create_model( $title, $file_path, $file_url, $uuid, $author_id ) {
        $post_id = wp_insert_post( array(
            'post_type'   => 'step_model',
            'post_title'  => sanitize_text_field( $title ),
            'post_name'   => $uuid,
            'post_status' => 'publish',
            'post_author' => $author_id,
        ), true );

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        update_post_meta( $post_id, '_wpsv_file_path', $file_path );
        update_post_meta( $post_id, '_wpsv_file_url',  $file_url );
        update_post_meta( $post_id, '_wpsv_uuid',      $uuid );
        update_post_meta( $post_id, '_wpsv_file_size', filesize( $file_path ) );
        update_post_meta( $post_id, '_wpsv_uploaded',  current_time( 'mysql' ) );

        return $post_id;
    }
}
