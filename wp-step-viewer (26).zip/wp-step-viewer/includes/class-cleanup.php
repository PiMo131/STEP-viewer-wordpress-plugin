<?php
defined( 'ABSPATH' ) || exit;

class WPSV_Cleanup {

    public static function init() {
        add_action( 'wpsv_daily_cleanup', array( __CLASS__, 'run' ) );
        add_action( 'init', array( __CLASS__, 'schedule' ) );
    }

    public static function schedule() {
        if ( ! wp_next_scheduled( 'wpsv_daily_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'wpsv_daily_cleanup' );
        }
    }

    public static function run() {
        $today = date( 'Y-m-d' );
        $posts = get_posts( array(
            'post_type'      => 'step_model',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'meta_query'     => array(
                'relation' => 'AND',
                array( 'key' => '_wpsv_expires', 'value' => '', 'compare' => '!=' ),
                array( 'key' => '_wpsv_expires', 'value' => $today, 'compare' => '<=', 'type' => 'DATE' ),
            ),
        ) );

        foreach ( $posts as $post ) {
            $file_path = get_post_meta( $post->ID, '_wpsv_file_path', true );
            if ( $file_path && file_exists( $file_path ) ) {
                @unlink( $file_path );
            }
            wp_delete_post( $post->ID, true );
        }
    }

    public static function deactivate() {
        $ts = wp_next_scheduled( 'wpsv_daily_cleanup' );
        if ( $ts ) {
            wp_unschedule_event( $ts, 'wpsv_daily_cleanup' );
        }
    }
}
