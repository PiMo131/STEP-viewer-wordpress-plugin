<?php
defined( 'ABSPATH' ) || exit;

class WPSV_Admin {

    public static function init() {
        add_action( 'admin_menu',            array( __CLASS__, 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'admin_init',            array( __CLASS__, 'redirect_uploader' ) );
        // Repair caps on every admin load — fixes post-reinstall issues
        add_action( 'admin_init',            array( __CLASS__, 'ensure_caps' ) );
    }

    /**
     * Make sure administrator always has the custom caps.
     * This repairs the role after plugin reinstalls or deactivation/activation cycles.
     */
    public static function ensure_caps() {
        $admin = get_role( 'administrator' );
        if ( ! $admin ) return;
        foreach ( array( 'publish_step_models', 'edit_step_models', 'delete_step_models', 'manage_step_models' ) as $cap ) {
            if ( ! $admin->has_cap( $cap ) ) {
                $admin->add_cap( $cap );
            }
        }
    }

    public static function register_menu() {
        // Main menu: publish_step_models — both admins and step_uploader have this cap.
        add_menu_page(
            'STEP Viewer', 'STEP Viewer', 'publish_step_models',
            'wpsv-upload', array( __CLASS__, 'page_upload' ),
            'dashicons-media-interactive', 25
        );

        // Upload is also the first submenu (renames the auto-generated duplicate)
        add_submenu_page(
            'wpsv-upload', 'Uploaden', 'Uploaden',
            'publish_step_models', 'wpsv-upload', array( __CLASS__, 'page_upload' )
        );

        // Admin-only submenus
        add_submenu_page(
            'wpsv-upload', 'Alle Modellen', 'Alle Modellen',
            'manage_step_models', 'wpsv-models', array( __CLASS__, 'page_models' )
        );
        add_submenu_page(
            'wpsv-upload', 'Instellingen', 'Instellingen',
            'manage_options', 'wpsv-settings', array( __CLASS__, 'page_settings' )
        );
    }

    public static function enqueue_assets( $hook ) {
        // Match any of our plugin pages regardless of capability-derived hook prefix
        $slugs = array( 'wpsv-upload', 'wpsv-models', 'wpsv-settings' );
        $is_our_page = false;
        foreach ( $slugs as $slug ) {
            if ( strpos( $hook, $slug ) !== false ) {
                $is_our_page = true;
                break;
            }
        }
        if ( ! $is_our_page ) return;

        wp_enqueue_style( 'wpsv-admin', WPSV_PLUGIN_URL . 'admin/css/admin.css', array(), WPSV_VERSION );
        wp_enqueue_script( 'wpsv-admin', WPSV_PLUGIN_URL . 'admin/js/admin.js', array(), WPSV_VERSION, true );
        wp_localize_script( 'wpsv-admin', 'wpsv_admin', array(
            'ajax_url'     => admin_url( 'admin-ajax.php' ),
            'upload_nonce' => wp_create_nonce( 'wpsv_upload_nonce' ),
            'delete_nonce' => wp_create_nonce( 'wpsv_delete_nonce' ),
            'max_size_mb'  => 256,
            'strings'      => array(
                'confirm_delete' => 'Weet je zeker dat je dit model wilt verwijderen?',
            ),
        ) );
    }

    public static function page_upload()   { require WPSV_PLUGIN_DIR . 'admin/views/upload-page.php'; }
    public static function page_models()   { require WPSV_PLUGIN_DIR . 'admin/views/models-page.php'; }
    public static function page_settings() { require WPSV_PLUGIN_DIR . 'admin/views/settings-page.php'; }

    public static function redirect_uploader() {
        $user = wp_get_current_user();
        if ( ! $user || ! in_array( 'step_uploader', (array) $user->roles, true ) ) return;
        $screen = get_current_screen();
        if ( $screen && $screen->id === 'dashboard' ) {
            wp_redirect( admin_url( 'admin.php?page=wpsv-upload' ) );
            exit;
        }
    }
}
