<?php
defined( 'ABSPATH' ) || exit;

class WPSV_Roles {

    public static function activate() {
        add_role( 'step_uploader', 'STEP Uploader', array(
            'read'                => true,
            'upload_files'        => false,
            'publish_step_models' => true,
            'edit_step_models'    => true,
        ) );

        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->add_cap( 'publish_step_models' );
            $admin->add_cap( 'edit_step_models' );
            $admin->add_cap( 'delete_step_models' );
            $admin->add_cap( 'manage_step_models' );
        }

        self::create_upload_dir();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        remove_role( 'step_uploader' );
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->remove_cap( 'publish_step_models' );
            $admin->remove_cap( 'edit_step_models' );
            $admin->remove_cap( 'delete_step_models' );
            $admin->remove_cap( 'manage_step_models' );
        }
        flush_rewrite_rules();
    }

    public static function create_upload_dir() {
        $upload_base = wp_upload_dir();
        $dir = trailingslashit( $upload_base['basedir'] ) . WPSV_UPLOAD_SUBDIR;
        if ( ! file_exists( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        file_put_contents( $dir . '/.htaccess', "Options -Indexes\n" );
    }

    public static function current_user_can_upload() {
        return current_user_can( 'publish_step_models' );
    }
}
