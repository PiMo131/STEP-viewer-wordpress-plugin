<?php
defined( 'ABSPATH' ) || exit;

class WPSV_Uploader {

    public static function init() {
        add_filter( 'upload_mimes', array( __CLASS__, 'allow_step_mime' ) );
        add_filter( 'wp_check_filetype_and_ext', array( __CLASS__, 'fix_step_filetype' ), 10, 4 );
        add_action( 'wp_ajax_wpsv_upload', array( __CLASS__, 'handle_upload' ) );
        add_action( 'wp_ajax_wpsv_delete', array( __CLASS__, 'handle_delete' ) );
    }

    public static function allow_step_mime( $mimes ) {
        $mimes['step'] = 'application/step';
        $mimes['stp']  = 'application/step';
        return $mimes;
    }

    public static function fix_step_filetype( $data, $file, $filename, $mimes ) {
        $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        if ( in_array( $ext, array( 'step', 'stp' ), true ) ) {
            $data['ext']  = $ext;
            $data['type'] = 'application/step';
        }
        return $data;
    }

    public static function handle_upload() {
        check_ajax_referer( 'wpsv_upload_nonce', 'nonce' );

        if ( ! WPSV_Roles::current_user_can_upload() ) {
            wp_send_json_error( array( 'message' => 'Geen toegang.' ), 403 );
        }

        if ( empty( $_FILES['step_file'] ) ) {
            wp_send_json_error( array( 'message' => 'Geen bestand ontvangen.' ) );
        }

        $file = $_FILES['step_file'];
        $ext  = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );

        if ( ! in_array( $ext, array( 'step', 'stp' ), true ) ) {
            wp_send_json_error( array( 'message' => 'Alleen .step en .stp bestanden zijn toegestaan.' ) );
        }

        if ( $file['size'] > 256 * 1024 * 1024 ) {
            wp_send_json_error( array( 'message' => 'Bestand is te groot (max 256 MB).' ) );
        }

        if ( $file['error'] !== UPLOAD_ERR_OK ) {
            wp_send_json_error( array( 'message' => 'Upload fout: ' . $file['error'] ) );
        }

        $uuid       = bin2hex( random_bytes( 8 ) );
        $upload     = wp_upload_dir();
        $target_dir = trailingslashit( $upload['basedir'] ) . WPSV_UPLOAD_SUBDIR;
        $target_url = trailingslashit( $upload['baseurl'] ) . WPSV_UPLOAD_SUBDIR;

        WPSV_Roles::create_upload_dir();

        $stored_name = $uuid . '.' . $ext;
        $target_file = $target_dir . '/' . $stored_name;
        $target_file_url = $target_url . '/' . $stored_name;

        if ( ! move_uploaded_file( $file['tmp_name'], $target_file ) ) {
            wp_send_json_error( array( 'message' => 'Bestand kon niet worden opgeslagen.' ) );
        }

        $title = ! empty( $_POST['model_title'] )
            ? sanitize_text_field( wp_unslash( $_POST['model_title'] ) )
            : pathinfo( sanitize_file_name( $file['name'] ), PATHINFO_FILENAME );

        $post_id = WPSV_Post_Types::create_model(
            $title, $target_file, $target_file_url, $uuid, get_current_user_id()
        );

        if ( is_wp_error( $post_id ) ) {
            @unlink( $target_file );
            wp_send_json_error( array( 'message' => $post_id->get_error_message() ) );
        }

        // Handle expiry
        $keep_forever = ! empty( $_POST['keep_forever'] );
        if ( $keep_forever ) {
            update_post_meta( $post_id, '_wpsv_expires', '' );
        } else {
            $days = max( 1, intval( isset( $_POST['expire_days'] ) ? $_POST['expire_days'] : 14 ) );
            update_post_meta( $post_id, '_wpsv_expires', date( 'Y-m-d', strtotime( '+' . $days . ' days' ) ) );
        }

        $expires_raw = get_post_meta( $post_id, '_wpsv_expires', true );
        $expires_fmt = $expires_raw ? date_i18n( get_option( 'date_format' ), strtotime( $expires_raw ) ) : '';

        wp_send_json_success( array(
            'message'    => 'STEP bestand succesvol geupload!',
            'viewer_url' => get_permalink( $post_id ),
            'uuid'       => $uuid,
            'post_id'    => $post_id,
            'file_size'  => size_format( $file['size'] ),
            'title'      => $title,
            'expires'    => $expires_fmt,
        ) );
    }

    public static function handle_delete() {
        check_ajax_referer( 'wpsv_delete_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_step_models' ) ) {
            wp_send_json_error( array( 'message' => 'Geen toegang.' ), 403 );
        }

        $post_id = intval( isset( $_POST['post_id'] ) ? $_POST['post_id'] : 0 );
        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => 'Ongeldig model ID.' ) );
        }

        $file_path = get_post_meta( $post_id, '_wpsv_file_path', true );
        if ( $file_path && file_exists( $file_path ) ) {
            @unlink( $file_path );
        }

        wp_delete_post( $post_id, true );
        wp_send_json_success( array( 'message' => 'Model verwijderd.' ) );
    }
}
