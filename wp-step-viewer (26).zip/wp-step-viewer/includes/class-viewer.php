<?php
defined( 'ABSPATH' ) || exit;

class WPSV_Viewer {

    public static function init() {
        add_action( 'template_redirect', array( __CLASS__, 'maybe_render_viewer' ) );
    }

    public static function maybe_render_viewer() {
        if ( ! is_singular( 'step_model' ) ) return;
        if ( get_option( 'wpsv_require_login', 0 ) && ! is_user_logged_in() ) auth_redirect();
        global $post;
        if ( ! $post ) return;

        $post_id    = $post->ID;
        $file_url   = get_post_meta( $post_id, '_wpsv_file_url', true );
        $file_size  = get_post_meta( $post_id, '_wpsv_file_size', true );
        $uploaded   = get_post_meta( $post_id, '_wpsv_uploaded', true );
        $expires    = get_post_meta( $post_id, '_wpsv_expires', true );
        $site_title = get_option( 'wpsv_site_title', get_bloginfo( 'name' ) );
        $title      = get_the_title( $post );
        $plugin_url = WPSV_PLUGIN_URL;

        if ( ! $file_url ) wp_die( 'STEP bestand niet gevonden.' );

        $meta = array();
        if ( $file_size ) $meta[] = size_format( (int) $file_size );
        if ( $uploaded )  $meta[] = date_i18n( 'd M Y', strtotime( $uploaded ) );
        if ( $expires )   $meta[] = 'Verloopt: ' . date_i18n( 'd M Y', strtotime( $expires ) );

        header( 'Content-Type: text/html; charset=utf-8' );
        self::render( $title, $site_title, $file_url, $plugin_url, $meta );
        exit;
    }

    private static function render( $title, $site_title, $file_url, $plugin_url, $meta ) {
        $o3dv_url = esc_url( $plugin_url . 'public/js/o3dv.min.js' );
        $occt_url = esc_url( $plugin_url . 'public/occt/' );
        ?>
<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo esc_html( $title ); ?> &ndash; <?php echo esc_html( $site_title ); ?></title>
<meta name="robots" content="noindex">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;overflow:hidden;background:#0f172a;font-family:system-ui,-apple-system,sans-serif;color:#f1f5f9}
#bar{position:fixed;top:0;left:0;right:0;z-index:200;height:48px;display:flex;align-items:center;gap:10px;padding:0 14px;background:rgba(8,12,24,.93);backdrop-filter:blur(10px);border-bottom:1px solid rgba(255,255,255,.06)}
.bar-logo{font-size:18px;font-weight:800;flex-shrink:0;background:linear-gradient(135deg,#0ea5e9,#6366f1);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.bar-title{font-size:.88rem;font-weight:600;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bar-meta{font-size:.7rem;color:#475569;white-space:nowrap;flex-shrink:0}
.bar-btns{display:flex;gap:6px;flex-shrink:0}
.btn{display:inline-flex;align-items:center;gap:4px;padding:4px 11px;border-radius:5px;font-size:.78rem;font-weight:500;cursor:pointer;text-decoration:none;white-space:nowrap;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.06);color:#cbd5e1;transition:background .15s}
.btn:hover{background:rgba(255,255,255,.13);color:#fff}
.btn-share{background:rgba(14,165,233,.15);border-color:rgba(14,165,233,.3)}
#vwrap{position:fixed;top:48px;left:0;right:0;bottom:0}
#viewer{width:100%;height:100%;display:block;outline:none}
#panel{position:absolute;top:10px;left:10px;z-index:100;background:rgba(8,12,24,.92);border:1px solid rgba(255,255,255,.09);border-radius:10px;padding:12px 14px;width:200px;backdrop-filter:blur(8px);font-size:.78rem;display:none}
#panel h3{font-size:.66rem;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:.07em;margin-bottom:7px}
.dr{display:flex;justify-content:space-between;color:#94a3b8;line-height:2}
.dr b{color:#e2e8f0;font-family:monospace;font-weight:400;font-size:.8rem}
hr.pd{border:none;border-top:1px solid rgba(255,255,255,.06);margin:9px 0}
.prow{display:flex;gap:3px;flex-wrap:wrap;margin-top:5px}
.pill{flex:1;min-width:0;padding:5px 3px;border-radius:5px;font-size:.69rem;font-weight:600;text-align:center;cursor:pointer;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);color:#64748b;transition:all .15s;white-space:nowrap;user-select:none}
.pill:hover{background:rgba(255,255,255,.1);color:#ddd}
.pill.on-v{background:rgba(14,165,233,.22);border-color:rgba(14,165,233,.4);color:#7dd3fc}
.pill.on-t{background:rgba(99,102,241,.22);border-color:rgba(99,102,241,.4);color:#a5b4fc}
#mout{margin-top:8px;padding:7px 9px;border-radius:6px;background:rgba(99,102,241,.1);border:1px solid rgba(99,102,241,.2);font-size:.77rem;color:#c7d2fe;display:none;line-height:1.7}
#ncwrap{position:absolute;bottom:16px;right:16px;z-index:100;width:100px;height:100px;perspective:400px}
#nc{width:60px;height:60px;margin:20px;position:relative;transform-style:preserve-3d;transform:rotateX(-30deg) rotateY(-45deg)}
.fc{position:absolute;width:60px;height:60px;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;letter-spacing:.05em;border:1px solid rgba(255,255,255,.18);cursor:pointer;transition:background .15s;background:rgba(14,165,233,.1);color:rgba(148,163,184,.85);user-select:none}
.fc:hover{background:rgba(14,165,233,.32);color:#fff}
.fc.fr{transform:translateZ(30px)}.fc.bk{transform:rotateY(180deg) translateZ(30px)}
.fc.ri{transform:rotateY(90deg) translateZ(30px)}.fc.le{transform:rotateY(-90deg) translateZ(30px)}
.fc.tp{transform:rotateX(90deg) translateZ(30px)}.fc.bt{transform:rotateX(-90deg) translateZ(30px)}
#dsvg{position:absolute;inset:0;pointer-events:none;z-index:90;overflow:visible}
#xh{position:absolute;pointer-events:none;z-index:150;width:20px;height:20px;display:none;transform:translate(-50%,-50%)}
#xh::before,#xh::after{content:"";position:absolute;background:#a5b4fc}
#xh::before{width:2px;height:100%;left:9px;top:0}
#xh::after{width:100%;height:2px;top:9px;left:0}
#ovl{position:absolute;inset:0;z-index:10;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;background:#0f172a;transition:opacity .4s}
.spin{width:42px;height:42px;border:3px solid rgba(255,255,255,.07);border-top-color:#0ea5e9;border-radius:50%;animation:sp .75s linear infinite}
@keyframes sp{to{transform:rotate(360deg)}}
#ovlmsg{color:#475569;font-size:.85rem}
#errbox{display:none;position:absolute;inset:0;z-index:10;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:40px;text-align:center;background:#0f172a}
#errbox h2{font-size:1.1rem}
#errbox p{color:#475569;max-width:380px;font-size:.82rem}
#toast{position:fixed;bottom:16px;left:50%;transform:translateX(-50%) translateY(60px);background:#1e293b;color:#f1f5f9;padding:8px 18px;border-radius:8px;font-size:.82rem;border:1px solid rgba(255,255,255,.07);transition:transform .25s;z-index:300;pointer-events:none}
#toast.show{transform:translateX(-50%) translateY(0)}
</style>
</head>
<body>

<div id="bar">
    <span class="bar-logo">&#11041;</span>
    <span class="bar-title"><?php echo esc_html( $title ); ?></span>
    <span class="bar-meta"><?php echo implode( ' &middot; ', array_map( 'esc_html', $meta ) ); ?></span>
    <div class="bar-btns">
        <button class="btn btn-share" onclick="copyLink()">&#128279; Kopieer link</button>
    </div>
</div>

<div id="vwrap">
    <div id="panel">
        <h3>Afmetingen</h3>
        <div class="dr"><span>Breedte X</span><b id="dx">&mdash;</b></div>
        <div class="dr"><span>Hoogte Y</span><b id="dy">&mdash;</b></div>
        <div class="dr"><span>Diepte Z</span><b id="dz">&mdash;</b></div>
        <div class="dr"><span>Volume</span><b id="dv">&mdash;</b></div>
        <hr class="pd">
        <h3>Weergave</h3>
        <div class="prow">
            <div class="pill on-v" id="v-sh" onclick="setMode('shaded')">Shaded</div>
            <div class="pill"      id="v-wf" onclick="setMode('wire')">Wireframe</div>
            <div class="pill"      id="v-pe" onclick="togglePersp()">Persp.</div>
        </div>
        <hr class="pd">
        <h3>Meten</h3>
        <div class="prow">
            <div class="pill" id="t-di" onclick="setTool('dist')" title="Klik 2 punten">&#128207; Afstand</div>
            <div class="pill" id="t-an" onclick="setTool('ang')"  title="Klik 3 punten">&#128208; Hoek</div>
            <div class="pill" id="t-cl" onclick="setTool('stop')">&#10005; Stop</div>
        </div>
        <div id="mout"></div>
        <hr class="pd">
        <h3>Schaal</h3>
        <div class="prow">
            <div class="pill" id="b-tog" onclick="toggleBanana(this)">&#127820; Banaan</div>
        </div>
        <div id="b-info" style="display:none;margin-top:6px;font-size:.69rem;color:#64748b;line-height:1.6;">
            Banaan &#8776; 180&nbsp;mm
        </div>
    </div>

    <div id="ncwrap">
        <div id="nc">
            <div class="fc fr" onclick="snapCam('front')">VOOR</div>
            <div class="fc bk" onclick="snapCam('back')">ACHTER</div>
            <div class="fc ri" onclick="snapCam('right')">RECHTS</div>
            <div class="fc le" onclick="snapCam('left')">LINKS</div>
            <div class="fc tp" onclick="snapCam('top')">BOVEN</div>
            <div class="fc bt" onclick="snapCam('bottom')">ONDER</div>
        </div>
    </div>

    <svg id="dsvg" xmlns="http://www.w3.org/2000/svg"></svg>
    <div id="xh"></div>
    <div id="ovl"><div class="spin"></div><p id="ovlmsg">Viewer laden&hellip;</p></div>
    <div id="errbox"><h2>&#9888; Model laden mislukt</h2><p>Ververs de pagina om het opnieuw te proberen.</p></div>
    <div id="viewer"></div>
</div>
<div id="toast"></div>

<script>
(function(){
    var L = <?php echo wp_json_encode( $occt_url ); ?>;
    var _f = window.fetch.bind(window);
    window.fetch = function(u,o){
        if(typeof u==='string'&&u.indexOf('occt-import-js')!==-1) u=L+u.split('/').pop();
        return _f(u,o);
    };
})();
</script>
<script src="<?php echo $o3dv_url; ?>"></script>
<script>
'use strict';

var FILE_URL = <?php echo wp_json_encode( $file_url ); ?>;

var gViewer  = null;
var gCam     = null;   // THREE.Camera — found via deepFind
var gScene   = null;   // THREE.Scene  — found via deepFind
var gMeshes  = [];     // THREE.Mesh[] — traversed from scene
var V3       = null;   // THREE.Vector3 constructor — extracted from gCam.position

var gModeWire = false;
var gPersp    = true;
var curTool   = 'stop';
var mPts      = [];
var dimLines  = [];
var ncHash    = '';

// ── Boot ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function(){
    var ovl=document.getElementById('ovl');
    var msg=document.getElementById('ovlmsg');
    var err=document.getElementById('errbox');
    var con=document.getElementById('viewer');

    if(typeof OV==='undefined'){
        ovl.style.display='none'; err.style.display='flex'; return;
    }
    msg.textContent='STEP model laden\u2026';

    gViewer=new OV.EmbeddedViewer(con,{
        backgroundColor:  new OV.RGBAColor(15,23,42,255),
        defaultColor:     new OV.RGBColor(160,175,195),
        onModelLoaded:    function(){ onReady(con,ovl); },
        onModelLoadFailed:function(){ ovl.style.display='none'; err.style.display='flex'; }
    });
    gViewer.LoadModelFromUrlList([FILE_URL]);

    setTimeout(function(){
        var cv=con.querySelector('canvas');
        if(cv){
            cv.addEventListener('click',    onCanvasClick);
            cv.addEventListener('mousemove',onMouseMove);
        }
    },800);

    setTimeout(function(){
        if(ovl.style.display!=='none'&&ovl.style.opacity!=='0'){
            ovl.style.display='none'; err.style.display='flex';
        }
    },90000);
});

// ── Model ready ───────────────────────────────────────────────────────────────
function onReady(con,ovl){
    grabInternals(con);
    buildBBox();
    startNavSync();

    // Only show panel when we actually have meshes (tools won't work without them)
    if(gCam && gMeshes.length > 0){
        document.getElementById('panel').style.display='block';
    }
    ovl.style.opacity='0';
    setTimeout(function(){ ovl.style.display='none'; },400);
}

// ── Grab Three.js internals ───────────────────────────────────────────────────
// o3dv bundles its own Three.js — window.THREE is undefined.
// We deep-search the viewer object for objects with isCamera/isScene duck-type flags.
// Then we extract the Vector3 class from gCam.position.constructor so we can
// do raycasting and projections using the SAME Three.js instance as the meshes.
function grabInternals(con){
    try{
        var v=gViewer.GetViewer();
        var seen=new Set();

        function deepFind(obj, test, depth){
            if(depth>8||!obj||typeof obj!=='object') return null;
            if(seen.has(obj)) return null;
            seen.add(obj);
            if(test(obj)) return obj;
            var keys=Object.keys(obj);
            for(var i=0;i<keys.length;i++){
                var k=keys[i];
                if(k==='parent'||k==='_listeners'||k==='__webglObjects') continue;
                try{
                    var r=deepFind(obj[k],test,depth+1);
                    if(r) return r;
                }catch(e){}
            }
            return null;
        }

        gCam   = deepFind(v,function(o){ return o&&o.isCamera===true; },0);
        seen   = new Set();
        gScene = deepFind(v,function(o){ return o&&o.isScene===true; },0);

        if(gScene) gScene.traverse(function(o){ if(o.isMesh) gMeshes.push(o); });

        // KEY: extract Vector3 from the camera's position property.
        // gCam.position IS a THREE.Vector3 from o3dv's own THREE instance.
        // Using its constructor ensures all THREE math is from the same instance.
        if(gCam&&gCam.position) V3=gCam.position.constructor;

        console.log('WPSV: cam=',!!gCam,'scene=',!!gScene,'meshes=',gMeshes.length,'V3=',!!V3);
    }catch(e){ console.warn('grabInternals:',e); }
}

// ── BBox + volume ─────────────────────────────────────────────────────────────
var gBBox = null; // world space bounding box {x0,y0,z0,x1,y1,z1}

function buildBBox(){
    try{
        var model=gViewer.GetModel();
        if(!model) return;
        var x0=1e18,y0=1e18,z0=1e18,x1=-1e18,y1=-1e18,z1=-1e18,vol=0;
        for(var mi=0;mi<model.MeshCount();mi++){
            var m=model.GetMesh(mi);
            for(var vi=0;vi<m.VertexCount();vi++){
                var vv=m.GetVertex(vi);
                if(vv.x<x0)x0=vv.x; if(vv.x>x1)x1=vv.x;
                if(vv.y<y0)y0=vv.y; if(vv.y>y1)y1=vv.y;
                if(vv.z<z0)z0=vv.z; if(vv.z>z1)z1=vv.z;
            }
            for(var ti=0;ti<m.TriangleCount();ti++){
                var t=m.GetTriangle(ti);
                var a=m.GetVertex(t.v0),b=m.GetVertex(t.v1),c=m.GetVertex(t.v2);
                vol+=(a.x*(b.y*c.z-b.z*c.y)+a.y*(b.z*c.x-b.x*c.z)+a.z*(b.x*c.y-b.y*c.x))/6;
            }
        }
        if(isFinite(x0)){
            gBBox={x0:x0,y0:y0,z0:z0,x1:x1,y1:y1,z1:z1};
            document.getElementById('dx').textContent=f2(x1-x0)+' mm';
            document.getElementById('dy').textContent=f2(y1-y0)+' mm';
            document.getElementById('dz').textContent=f2(z1-z0)+' mm';
            document.getElementById('dv').textContent=fVol(Math.abs(vol));
        }
    }catch(e){ console.warn('bbox:',e); }
}

function f2(n){ return (Math.round(n*100)/100).toFixed(2); }
function fVol(v){
    if(v>1e9) return f2(v/1e9)+' dm\u00b3';
    if(v>1e3) return f2(v/1e3)+' cm\u00b3';
    return f2(v)+' mm\u00b3';
}

// ── View modes ────────────────────────────────────────────────────────────────
function setMode(m){
    gModeWire=(m==='wire');
    document.getElementById('v-sh').classList.toggle('on-v',m==='shaded');
    document.getElementById('v-wf').classList.toggle('on-v',m==='wire');
    gMeshes.forEach(function(obj){
        var mats=Array.isArray(obj.material)?obj.material:[obj.material];
        mats.forEach(function(mat){ if(mat) mat.wireframe=gModeWire; });
    });
    try{ gViewer.GetViewer().Render(); }catch(e){}
}

function togglePersp(){
    gPersp=!gPersp;
    document.getElementById('v-pe').classList.toggle('on-v',!gPersp);
    try{
        var mode=gPersp?OV.ProjectionMode.Perspective:OV.ProjectionMode.Orthographic;
        gViewer.GetViewer().SetProjectionMode(mode);
        gViewer.GetViewer().Render();
    }catch(e){ console.warn('persp:',e); }
}

// ── NavCube sync ──────────────────────────────────────────────────────────────
function startNavSync(){
    function frame(){
        requestAnimationFrame(frame);
        if(!gCam) return;
        var p=gCam.position;
        var h=p.x.toFixed(1)+','+p.y.toFixed(1)+','+p.z.toFixed(1);
        if(h===ncHash) return;
        ncHash=h;
        var len=Math.sqrt(p.x*p.x+p.y*p.y+p.z*p.z)||1;
        var theta=Math.atan2(p.x/len,p.z/len)*180/Math.PI;
        var phi=Math.asin(Math.max(-1,Math.min(1,p.y/len)))*180/Math.PI;
        var nc=document.getElementById('nc');
        nc.style.transition='none';
        nc.style.transform='rotateX('+(-phi)+'deg) rotateY('+(theta)+'deg)';
    }
    frame();
}

var SNAP_CSS={front:{rx:0,ry:0},back:{rx:0,ry:180},right:{rx:0,ry:-90},left:{rx:0,ry:90},top:{rx:-90,ry:0},bottom:{rx:90,ry:0}};
var SNAP_DIR={front:[0,0,1],back:[0,0,-1],right:[1,0,0],left:[-1,0,0],top:[0,1,0],bottom:[0,-1,0]};

function snapCam(view){
    var r=SNAP_CSS[view];
    var nc=document.getElementById('nc');
    nc.style.transition='transform .45s cubic-bezier(.4,0,.2,1)';
    nc.style.transform='rotateX('+r.rx+'deg) rotateY('+r.ry+'deg)';
    setTimeout(function(){ ncHash=''; },50);
    try{
        var v=gViewer.GetViewer();
        var bs=v.GetBoundingSphere(function(){ return true; });
        if(!bs) return;
        var c=bs.center,d=bs.radius*2.5,dr=SNAP_DIR[view];
        var up=(view==='top'||view==='bottom')?new OV.Coord3D(0,0,1):new OV.Coord3D(0,1,0);
        v.SetCamera(new OV.Camera(
            new OV.Coord3D(c.x+dr[0]*d,c.y+dr[1]*d,c.z+dr[2]*d),
            new OV.Coord3D(c.x,c.y,c.z),up,45
        ));
        v.Render();
    }catch(e){ console.warn('snapCam:',e); }
}

// ── Measure tools ─────────────────────────────────────────────────────────────
function setTool(t){
    curTool=t; mPts=[];
    clearDimLines();
    var mo=document.getElementById('mout');
    mo.style.display='none'; mo.innerHTML='';
    document.getElementById('t-di').classList.toggle('on-t',t==='dist');
    document.getElementById('t-an').classList.toggle('on-t',t==='ang');
    document.getElementById('t-cl').classList.toggle('on-t',t==='stop');
    document.getElementById('xh').style.display=t!=='stop'?'block':'none';
    document.getElementById('viewer').style.cursor=t!=='stop'?'crosshair':'';
    if(t!=='stop') showMeasure('Klik punt 1 op het model\u2026');
}

function onMouseMove(e){
    if(curTool==='stop') return;
    var x=document.getElementById('xh');
    x.style.left=e.clientX+'px';
    x.style.top=(e.clientY-48)+'px';
}

function onCanvasClick(e){
    if(curTool==='stop') return;
    var pt=pickPoint(e);
    if(!pt){ showToast('Klik op het model'); return; }
    mPts.push(pt);
    var need=curTool==='dist'?2:3;
    if(mPts.length<need){
        showMeasure('Punt '+mPts.length+'/'+need+' \u2014 klik punt '+(mPts.length+1));
        return;
    }
    if(curTool==='dist'){
        var dx=mPts[1].x-mPts[0].x,dy=mPts[1].y-mPts[0].y,dz=mPts[1].z-mPts[0].z;
        var d=Math.sqrt(dx*dx+dy*dy+dz*dz);
        showMeasure('&#128207; Afstand: <strong>'+f2(d)+' mm</strong>');
        drawDimLine(mPts[0],mPts[1],f2(d)+' mm');
    }else{
        var ba={x:mPts[0].x-mPts[1].x,y:mPts[0].y-mPts[1].y,z:mPts[0].z-mPts[1].z};
        var bc={x:mPts[2].x-mPts[1].x,y:mPts[2].y-mPts[1].y,z:mPts[2].z-mPts[1].z};
        var dot=ba.x*bc.x+ba.y*bc.y+ba.z*bc.z;
        var la=Math.sqrt(ba.x*ba.x+ba.y*ba.y+ba.z*ba.z);
        var lc=Math.sqrt(bc.x*bc.x+bc.y*bc.y+bc.z*bc.z);
        var ang=Math.acos(Math.max(-1,Math.min(1,dot/(la*lc))))*180/Math.PI;
        showMeasure('&#128208; Hoek: <strong>'+f2(ang)+'&deg;</strong>');
    }
    mPts=[];
}

// ── Ray picking using o3dv's own THREE instance ───────────────────────────────
// V3 = gCam.position.constructor = THREE.Vector3 (from o3dv's bundled THREE).
// We use V3's unproject() method to build the ray — same instance as the meshes,
// so geometry attribute reads and matrix transforms all work correctly.
function makeRay(ndcX, ndcY){
    if(!gCam||!V3) return null;
    try{
        // Near and far points in NDC, unprojected to world space
        var near = new V3(ndcX, ndcY, -1).unproject(gCam);
        var far  = new V3(ndcX, ndcY,  1).unproject(gCam);
        var dx=far.x-near.x, dy=far.y-near.y, dz=far.z-near.z;
        var len=Math.sqrt(dx*dx+dy*dy+dz*dz)||1;
        return {
            ox:near.x, oy:near.y, oz:near.z,
            dx:dx/len,  dy:dy/len,  dz:dz/len
        };
    }catch(e){ console.warn('makeRay:',e); return null; }
}

function pickPoint(e){
    var con=document.getElementById('viewer');
    var rect=con.getBoundingClientRect();
    var ndcX=((e.clientX-rect.left)/rect.width)*2-1;
    var ndcY=-((e.clientY-rect.top)/rect.height)*2+1;
    var ray=makeRay(ndcX,ndcY);
    if(!ray) return null;

    var bestT=Infinity, bestPt=null, EPS=1e-7;

    // Raycast each THREE.Mesh using its BufferGeometry + matrixWorld
    // This works because V3 and the mesh are from the same THREE instance
    gMeshes.forEach(function(mesh){
        try{
            var geo=mesh.geometry;
            var posAttr=geo.attributes.position;
            var idx=geo.index;
            var mat=mesh.matrixWorld;

            // Helper: get world-space vertex i
            function wv(i){
                var v=new V3();
                v.fromBufferAttribute(posAttr,i);
                v.applyMatrix4(mat);
                return v;
            }

            var triCount=idx ? idx.count/3 : posAttr.count/3;
            for(var t=0;t<triCount;t++){
                var i0=idx?idx.getX(t*3)  :t*3;
                var i1=idx?idx.getX(t*3+1):t*3+1;
                var i2=idx?idx.getX(t*3+2):t*3+2;
                var v0=wv(i0),v1=wv(i1),v2=wv(i2);

                // Möller-Trumbore
                var e1x=v1.x-v0.x,e1y=v1.y-v0.y,e1z=v1.z-v0.z;
                var e2x=v2.x-v0.x,e2y=v2.y-v0.y,e2z=v2.z-v0.z;
                var hx=ray.dz*e2y-ray.dy*e2z, hy=ray.dx*e2z-ray.dz*e2x, hz=ray.dy*e2x-ray.dx*e2y;
                // Fix: h = cross(rd, e2)
                hx=ray.dy*e2z-ray.dz*e2y;
                hy=ray.dz*e2x-ray.dx*e2z;
                hz=ray.dx*e2y-ray.dy*e2x;
                var det=e1x*hx+e1y*hy+e1z*hz;
                if(Math.abs(det)<EPS) continue;
                var inv=1/det;
                var sx=ray.ox-v0.x,sy=ray.oy-v0.y,sz=ray.oz-v0.z;
                var u=(sx*hx+sy*hy+sz*hz)*inv;
                if(u<0||u>1) continue;
                var qx=sy*e1z-sz*e1y,qy=sz*e1x-sx*e1z,qz=sx*e1y-sy*e1x;
                var vv=(ray.dx*qx+ray.dy*qy+ray.dz*qz)*inv;
                if(vv<0||u+vv>1) continue;
                var tt=(e2x*qx+e2y*qy+e2z*qz)*inv;
                if(tt>EPS&&tt<bestT){
                    bestT=tt;
                    bestPt={
                        x:ray.ox+ray.dx*tt,
                        y:ray.oy+ray.dy*tt,
                        z:ray.oz+ray.dz*tt
                    };
                }
            }
        }catch(e2){ console.warn('mesh pick:',e2); }
    });
    return bestPt;
}

// ── Dimension line overlay ────────────────────────────────────────────────────
function drawDimLine(p1,p2,label){
    var s1=project(p1),s2=project(p2);
    if(!s1||!s2) return;
    var svg=document.getElementById('dsvg'),ns='http://www.w3.org/2000/svg';
    var g=document.createElementNS(ns,'g');
    function el(tag,a){ var e=document.createElementNS(ns,tag); for(var k in a) e.setAttribute(k,a[k]); return e; }
    g.appendChild(el('line',{x1:s1.x,y1:s1.y,x2:s2.x,y2:s2.y,stroke:'#a5b4fc','stroke-width':'1.5','stroke-dasharray':'5,3'}));
    var mx=(s1.x+s2.x)/2,my=(s1.y+s2.y)/2,tw=label.length*7;
    g.appendChild(el('rect',{x:mx-tw/2-4,y:my-22,width:tw+8,height:16,fill:'rgba(15,23,42,.9)',rx:4}));
    var txt=el('text',{x:mx,y:my-9,fill:'#e2e8f0','font-size':12,'font-weight':700,'font-family':'system-ui','text-anchor':'middle'});
    txt.textContent=label; g.appendChild(txt);
    [s1,s2].forEach(function(s){
        g.appendChild(el('circle',{cx:s.x,cy:s.y,r:4,fill:'#6366f1',stroke:'#a5b4fc','stroke-width':1.5}));
    });
    svg.appendChild(g); dimLines.push(g);
}

function project(pt){
    if(!gCam||!V3) return null;
    try{
        var con=document.getElementById('viewer'),r=con.getBoundingClientRect();
        var v=new V3(pt.x,pt.y,pt.z).project(gCam);
        return{x:(v.x+1)/2*r.width,y:(1-(v.y+1)/2)*r.height};
    }catch(e){ return null; }
}

function clearDimLines(){
    var svg=document.getElementById('dsvg');
    dimLines.forEach(function(g){ try{svg.removeChild(g);}catch(e){} });
    dimLines=[];
}

function showMeasure(html){ var el=document.getElementById('mout'); el.innerHTML=html; el.style.display='block'; }


// ── Banana for scale ──────────────────────────────────────────────────────────
var gBanana = null;

// Hardcoded spot locations for a consistent banana (i=spine index, j=circle index, r=radius)
var BSPOTS = [
    {i:10,j:3,r:4.5},{i:14,j:8,r:3.5},{i:20,j:1,r:5.0},
    {i:24,j:6,r:3.0},{i:18,j:10,r:4.2},{i:27,j:4,r:3.5},
    {i:13,j:9,r:2.8},{i:29,j:2,r:4.0},{i:22,j:12,r:2.5},
];

function toggleBanana(el){
    el.classList.toggle('on-v');
    var on = el.classList.contains('on-v');
    document.getElementById('b-info').style.display = on ? 'block' : 'none';
    if(on) addBanana(); else removeBanana();
}

function removeBanana(){
    if(!gBanana||!gScene) return;
    gScene.remove(gBanana);
    if(gBanana.geometry) gBanana.geometry.dispose();
    if(gBanana.material) gBanana.material.dispose();
    gBanana=null;
    try{ gViewer.GetViewer().Render(); }catch(e){}
}

function addBanana(){
    if(!gScene||!gMeshes.length||!V3) return;
    removeBanana();

    // Extract THREE constructors from existing mesh
    var M0   = gMeshes[0];
    var GEO  = M0.geometry.constructor;
    var ATTR = M0.geometry.attributes.position.constructor;
    var MESH = M0.constructor;

    var geo = buildBananaGeo(GEO, ATTR);
    var mat = buildBananaMat(M0);
    if(!mat){ showToast('Materiaal niet gevonden'); return; }
    gBanana = new MESH(geo, mat);

    // Position: right of bbox + 30mm gap, floor level, center Z
    var bb = gBBox || {x0:0,y0:0,z0:0,x1:100,y1:100,z1:100};
    var gap = (bb.x1 - bb.x0) * 0.12 + 20; // proportional gap, min 20mm
    gBanana.position.set(
        bb.x1 + gap,
        bb.y0,
        (bb.z0 + bb.z1) / 2
    );

    gScene.add(gBanana);
    try{ gViewer.GetViewer().Render(); }catch(e){}
}

function buildBananaGeo(GEO, ATTR){
    // Spine: standing banana 180mm tall, curves gently to the right
    // Each entry: {x, y, r} where r = cross-section radius at that point
    var spine = [
        {x:6,  y:0,   r:0.5},
        {x:11, y:15,  r:6  },
        {x:16, y:40,  r:12 },
        {x:20, y:75,  r:16 },
        {x:21, y:110, r:17 },
        {x:20, y:140, r:14 },
        {x:15, y:160, r:9  },
        {x:7,  y:173, r:5  },
        {x:2,  y:180, r:1  },
    ];

    var NS = 38;   // spine samples
    var NC = 12;   // circle segments
    var pts = crSpline(spine, NS);

    var pos=[], col=[], idx=[];

    for(var i=0;i<NS;i++){
        var p=pts[i];
        // Tangent in XY plane
        var tx,ty;
        if(i===0){tx=pts[1].x-pts[0].x; ty=pts[1].y-pts[0].y;}
        else if(i===NS-1){tx=pts[NS-1].x-pts[NS-2].x; ty=pts[NS-1].y-pts[NS-2].y;}
        else{tx=pts[i+1].x-pts[i-1].x; ty=pts[i+1].y-pts[i-1].y;}
        var tl=Math.sqrt(tx*tx+ty*ty)||1; tx/=tl; ty/=tl;
        // Normal: perpendicular to tangent in XY
        var nx=-ty, ny=tx;

        for(var j=0;j<NC;j++){
            var a=(j/NC)*Math.PI*2;
            var cos=Math.cos(a), sin=Math.sin(a);
            // vertex: spine + radial offset using tangent-normal frame
            pos.push(
                p.x + p.r*(nx*cos),
                p.y + p.r*(ny*cos),
                p.r*sin
            );
            // Color: yellow base, brown spots blended in
            var sp=spotFactor(i,j,NS,NC);
            var isStem=(i/NS>0.88); // top 12% = stem (slightly darker yellow-green)
            if(isStem){
                col.push(0.45, 0.32, 0.06); // brown stem
            } else {
                col.push(
                    Math.max(0, 0.98 - sp*0.60),   // R
                    Math.max(0, 0.82 - sp*0.60),   // G
                    Math.max(0, 0.04 + sp*0.01)    // B
                );
            }
        }
    }

    // Triangles between rings
    for(var i=0;i<NS-1;i++){
        for(var j=0;j<NC;j++){
            var a=i*NC+j, b=i*NC+(j+1)%NC;
            var cc=(i+1)*NC+j, d=(i+1)*NC+(j+1)%NC;
            idx.push(a,cc,b, b,cc,d);
        }
    }

    // Bottom cap (tip)
    var tipBot = pos.length/3;
    pos.push(pts[0].x, pts[0].y, 0);
    col.push(0.96, 0.80, 0.04);
    for(var j=0;j<NC;j++){
        idx.push(tipBot, j, (j+1)%NC);
    }

    // Top cap (stem tip)
    var tipTop = pos.length/3;
    var base=(NS-1)*NC;
    pos.push(pts[NS-1].x, pts[NS-1].y, 0);
    col.push(0.40, 0.28, 0.05);
    for(var j=0;j<NC;j++){
        idx.push(tipTop, base+(j+1)%NC, base+j);
    }

    var geo=new GEO();
    geo.setAttribute('position', new ATTR(new Float32Array(pos), 3));
    geo.setAttribute('color',    new ATTR(new Float32Array(col), 3));
    geo.setIndex(idx);
    geo.computeVertexNormals();
    return geo;
}

function buildBananaMat(mesh0){
    // material can be a single object OR an array — find first clonable one
    var srcMat = null;
    for(var mi=0; mi<gMeshes.length && !srcMat; mi++){
        var m = gMeshes[mi].material;
        var list = Array.isArray(m) ? m : [m];
        for(var li=0; li<list.length; li++){
            if(list[li] && typeof list[li].clone === 'function'){
                srcMat = list[li]; break;
            }
        }
    }
    if(!srcMat){ console.warn('WPSV: no clonable material found'); return null; }
    var mat = srcMat.clone();
    mat.vertexColors = true;
    if(mat.color)                    mat.color.setHex(0xffffff);
    if(mat.map !== undefined)        mat.map        = null;
    if(mat.normalMap !== undefined)  mat.normalMap  = null;
    if(mat.roughness !== undefined)  mat.roughness  = 0.6;
    if(mat.metalness !== undefined)  mat.metalness  = 0.0;
    if(mat.shininess !== undefined)  mat.shininess  = 40;
    mat.needsUpdate = true;
    return mat;
}

// Catmull-Rom spline interpolation
function crSpline(pts, N){
    var n=pts.length, out=[];
    for(var s=0;s<N;s++){
        var t=s/(N-1)*(n-1);
        var i=Math.min(Math.floor(t), n-2);
        var f=t-i;
        var p0=pts[Math.max(0,i-1)], p1=pts[i];
        var p2=pts[Math.min(n-1,i+1)], p3=pts[Math.min(n-1,i+2)];
        var f2=f*f, f3=f2*f;
        function cm(a,b,cc,d){
            return 0.5*((2*b)+(-a+cc)*f+(2*a-5*b+4*cc-d)*f2+(-a+3*b-3*cc+d)*f3);
        }
        out.push({x:cm(p0.x,p1.x,p2.x,p3.x), y:cm(p0.y,p1.y,p2.y,p3.y), r:Math.max(0,cm(p0.r,p1.r,p2.r,p3.r))});
    }
    return out;
}

// How brown is vertex (i,j) on a NS×NC grid?
function spotFactor(i,j,NS,NC){
    var f=0;
    for(var k=0;k<BSPOTS.length;k++){
        var s=BSPOTS[k];
        var di=i-s.i;
        var dj=Math.min(Math.abs(j-s.j), NC-Math.abs(j-s.j));
        var dist=Math.sqrt(di*di+dj*dj);
        if(dist<s.r) f=Math.max(f,(1-dist/s.r)*0.85);
    }
    return f;
}

function copyLink(){
    var url=window.location.href;
    if(navigator.clipboard) navigator.clipboard.writeText(url);
    else{ var t=document.createElement('textarea'); t.value=url; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t); }
    showToast('\u2713 Link gekopieerd!');
}
function showToast(msg){ var t=document.getElementById('toast'); t.textContent=msg; t.classList.add('show'); setTimeout(function(){ t.classList.remove('show'); },2200); }
</script>
</body>
</html>
<?php
    }
}
