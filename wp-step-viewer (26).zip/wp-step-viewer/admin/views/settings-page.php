<?php
defined( 'ABSPATH' ) || exit;
if ( isset( $_POST['wpsv_save'] ) ) {
    check_admin_referer( 'wpsv_settings' );
    update_option( 'wpsv_site_title',    sanitize_text_field( isset( $_POST['wpsv_site_title'] ) ? $_POST['wpsv_site_title'] : '' ) );
    update_option( 'wpsv_show_download', isset( $_POST['wpsv_show_download'] ) ? 1 : 0 );
    update_option( 'wpsv_require_login', isset( $_POST['wpsv_require_login'] ) ? 1 : 0 );
    echo '<div class="notice notice-success"><p>Instellingen opgeslagen.</p></div>';
}
?>
<div class="wrap">
    <h1>STEP Viewer &ndash; Instellingen</h1>
    <form method="post">
        <?php wp_nonce_field( 'wpsv_settings' ); ?>
        <table class="form-table">
            <tr>
                <th><label for="wpsv_site_title">Viewer paginatitel</label></th>
                <td><input type="text" name="wpsv_site_title" id="wpsv_site_title" class="regular-text" value="<?php echo esc_attr( get_option( 'wpsv_site_title', get_bloginfo('name') ) ); ?>"></td>
            </tr>
            <tr>
                <th>Download knop tonen</th>
                <td><label><input type="checkbox" name="wpsv_show_download" value="1" <?php checked( get_option( 'wpsv_show_download', 1 ), 1 ); ?>> Toon downloadknop op de viewer pagina</label></td>
            </tr>
            <tr>
                <th>Login vereist</th>
                <td><label><input type="checkbox" name="wpsv_require_login" value="1" <?php checked( get_option( 'wpsv_require_login', 0 ), 1 ); ?>> Alleen ingelogde gebruikers kunnen modellen bekijken</label></td>
            </tr>
        </table>
        <?php submit_button( 'Instellingen opslaan', 'primary', 'wpsv_save' ); ?>
    </form>
</div>
