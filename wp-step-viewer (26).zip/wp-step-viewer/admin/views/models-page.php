<?php
defined( 'ABSPATH' ) || exit;
$paged    = max( 1, intval( isset( $_GET['paged'] ) ? $_GET['paged'] : 1 ) );
$search   = sanitize_text_field( isset( $_GET['s'] ) ? $_GET['s'] : '' );
$args = array(
    'post_type'      => 'step_model',
    'post_status'    => 'publish',
    'posts_per_page' => 20,
    'paged'          => $paged,
    'orderby'        => 'date',
    'order'          => 'DESC',
);
if ( $search ) { $args['s'] = $search; }
$query     = new WP_Query( $args );
$total     = $query->found_posts;
$num_pages = ceil( $total / 20 );
?>
<div class="wrap wpsv-wrap">
    <h1>
        Alle STEP Modellen
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpsv-upload' ) ); ?>" class="page-title-action">+ Nieuw uploaden</a>
    </h1>
    <form method="get" action="">
        <input type="hidden" name="page" value="wpsv-models">
        <p class="search-box">
            <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="Zoeken op naam&hellip;">
            <button type="submit" class="button">Zoeken</button>
        </p>
    </form>
    <p style="color:#64748b;margin-bottom:12px;"><?php echo esc_html( $total ); ?> modellen gevonden</p>
    <?php if ( $query->have_posts() ) : ?>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Naam</th><th>Uploader</th><th>Grootte</th><th>Ge&uuml;pload</th><th>Verloopt</th><th>Viewer URL</th><th>Acties</th>
            </tr>
        </thead>
        <tbody>
        <?php while ( $query->have_posts() ) : $query->the_post();
            $pid     = get_the_ID();
            $fsize   = get_post_meta( $pid, '_wpsv_file_size', true );
            $furl    = get_post_meta( $pid, '_wpsv_file_url', true );
            $expires = get_post_meta( $pid, '_wpsv_expires', true );
            $viewer  = get_permalink( $pid );
        ?>
            <tr>
                <td><strong><?php the_title(); ?></strong><br><code style="font-size:.72rem;color:#94a3b8;"><?php echo esc_html( get_post_meta( $pid, '_wpsv_uuid', true ) ); ?></code></td>
                <td><?php echo esc_html( get_the_author() ); ?></td>
                <td><?php echo $fsize ? esc_html( size_format( (int) $fsize ) ) : '&mdash;'; ?></td>
                <td><?php echo esc_html( get_the_date() ); ?></td>
                <td><?php echo $expires ? esc_html( date_i18n( get_option('date_format'), strtotime($expires) ) ) : '&#8734; altijd'; ?></td>
                <td><input type="text" value="<?php echo esc_url( $viewer ); ?>" readonly onclick="this.select();" style="width:100%;font-size:.78rem;"></td>
                <td style="white-space:nowrap;">
                    <a href="<?php echo esc_url( $viewer ); ?>" target="_blank" class="button button-small">&#11041; Open</a>
                    <?php if ( $furl ) : ?>
                    <a href="<?php echo esc_url( $furl ); ?>" download class="button button-small">&darr; STEP</a>
                    <?php endif; ?>
                    <button type="button" class="button button-small button-link-delete wpsv-delete-btn" data-post-id="<?php echo esc_attr( $pid ); ?>">Verwijder</button>
                </td>
            </tr>
        <?php endwhile; wp_reset_postdata(); ?>
        </tbody>
    </table>
    <?php if ( $num_pages > 1 ) : ?>
    <div style="margin-top:12px;">
    <?php echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $num_pages ) ); ?>
    </div>
    <?php endif; ?>
    <?php else : ?>
    <p style="padding:32px;text-align:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;">
        Nog geen modellen. <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpsv-upload' ) ); ?>">Upload je eerste STEP bestand &rarr;</a>
    </p>
    <?php endif; ?>
</div>
