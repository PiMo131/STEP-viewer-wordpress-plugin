<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wrap wpsv-wrap">
    <h1 style="display:flex;align-items:center;gap:10px;">
        <span style="background:linear-gradient(135deg,#0ea5e9,#6366f1);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-size:28px;">&#11041;</span>
        STEP Model uploaden
    </h1>
    <p style="color:#64748b;margin-bottom:24px;">Upload een .step of .stp bestand en ontvang direct een deelbare 3D viewer link.</p>

    <div class="wpsv-card">
        <div id="wpsv-dropzone" class="wpsv-dropzone">
            <div style="text-align:center;padding:32px 16px;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="1.5" style="margin-bottom:12px">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
                </svg>
                <p style="font-size:1rem;font-weight:600;color:#334155;margin-bottom:8px;">Sleep je STEP bestand hiernaartoe</p>
                <p style="color:#94a3b8;margin-bottom:12px;">of</p>
                <label for="wpsv-file-input" class="button button-primary" style="cursor:pointer;">Bladeren&hellip;</label>
                <input type="file" id="wpsv-file-input" accept=".step,.stp" style="display:none">
                <p style="margin-top:12px;color:#94a3b8;font-size:.82rem;">Ondersteund: .step, .stp &mdash; max. 256 MB</p>
            </div>
        </div>

        <div id="wpsv-form" style="display:none">
            <div id="wpsv-file-preview" style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:14px;">
                <span style="font-size:24px;">&#128208;</span>
                <div style="flex:1">
                    <strong id="wpsv-file-name" style="display:block;"></strong>
                    <small id="wpsv-file-size" style="color:#64748b;"></small>
                </div>
                <button type="button" id="wpsv-remove-file" style="background:none;border:none;cursor:pointer;color:#94a3b8;font-size:18px;">&#10005;</button>
            </div>

            <label style="display:block;font-weight:600;margin-bottom:6px;font-size:.9rem;">Naam / omschrijving (optioneel)</label>
            <input type="text" id="wpsv-model-title" class="regular-text" style="width:100%;margin-bottom:14px;" placeholder="bv. Bracket v3 &ndash; aluminium">

            <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;padding:10px 14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;margin-bottom:16px;font-size:.88rem;">
                <span style="font-weight:600;">Automatisch verwijderen na</span>
                <div id="wpsv-expiry-ctrl" style="display:flex;align-items:center;gap:6px;">
                    <input type="number" id="wpsv-expire-days" value="14" min="1" max="365" style="width:60px;text-align:center;">
                    <span>dagen</span>
                </div>
                <label style="display:flex;align-items:center;gap:6px;cursor:pointer;margin-left:auto;">
                    <input type="checkbox" id="wpsv-keep-forever">
                    Altijd behouden
                </label>
            </div>

            <button type="button" id="wpsv-upload-btn" class="button button-primary" style="width:100%;height:44px;font-size:.95rem;">
                &#11041; Uploaden &amp; viewer openen
            </button>
        </div>

        <div id="wpsv-progress" style="display:none;text-align:center;padding:24px 0;">
            <div style="width:100%;height:8px;background:#e2e8f0;border-radius:99px;overflow:hidden;margin-bottom:12px;">
                <div id="wpsv-progress-fill" style="height:100%;width:0%;background:linear-gradient(90deg,#0ea5e9,#6366f1);border-radius:99px;transition:width .3s;"></div>
            </div>
            <p id="wpsv-progress-label" style="color:#64748b;font-size:.88rem;">Bezig met uploaden&hellip;</p>
        </div>

        <div id="wpsv-result" style="display:none;text-align:center;">
            <p style="font-size:40px;margin-bottom:8px;">&#9989;</p>
            <h2 style="margin-bottom:8px;">Upload geslaagd!</h2>
            <p style="color:#64748b;margin-bottom:14px;">Deel deze link met je team:</p>
            <div style="display:flex;gap:8px;margin-bottom:10px;">
                <input type="text" id="wpsv-result-url" class="large-text" readonly style="flex:1;">
                <button type="button" id="wpsv-copy-btn" class="button">Kopi&euml;ren</button>
            </div>
            <p id="wpsv-expiry-notice" style="color:#64748b;font-size:.82rem;margin-bottom:14px;"></p>
            <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
                <a id="wpsv-open-viewer" href="#" target="_blank" class="button button-primary">&#11041; Open 3D Viewer</a>
                <button type="button" id="wpsv-upload-another" class="button">Nog een bestand uploaden</button>
            </div>
        </div>

        <div id="wpsv-error" style="display:none;margin-top:14px;" class="notice notice-error">
            <p id="wpsv-error-msg"></p>
        </div>
    </div>

    <?php if ( current_user_can( 'manage_step_models' ) ) : ?>
    <p style="margin-top:16px;text-align:center;">
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wpsv-models' ) ); ?>">
            &rarr; Bekijk alle ge&uuml;ploade modellen
        </a>
    </p>
    <?php endif; ?>
</div>
