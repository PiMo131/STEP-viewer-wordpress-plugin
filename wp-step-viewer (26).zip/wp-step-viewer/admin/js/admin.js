/* global wpsv_admin */
(function () {
    'use strict';

    var dropzone    = document.getElementById('wpsv-dropzone');
    if (!dropzone) return;

    var fileInput   = document.getElementById('wpsv-file-input');
    var form        = document.getElementById('wpsv-form');
    var progress    = document.getElementById('wpsv-progress');
    var result      = document.getElementById('wpsv-result');
    var errorBox    = document.getElementById('wpsv-error');
    var uploadBtn   = document.getElementById('wpsv-upload-btn');
    var keepForever = document.getElementById('wpsv-keep-forever');
    var expiryCtrl  = document.getElementById('wpsv-expiry-ctrl');
    var selectedFile = null;

    fileInput.addEventListener('change', function () {
        if (this.files && this.files[0]) showFile(this.files[0]);
    });

    dropzone.addEventListener('dragover',  function (e) { e.preventDefault(); dropzone.classList.add('dragover'); });
    dropzone.addEventListener('dragleave', function ()  { dropzone.classList.remove('dragover'); });
    dropzone.addEventListener('drop', function (e) {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        if (e.dataTransfer.files && e.dataTransfer.files[0]) showFile(e.dataTransfer.files[0]);
    });

    keepForever.addEventListener('change', function () {
        expiryCtrl.style.opacity = this.checked ? '.4' : '1';
        expiryCtrl.style.pointerEvents = this.checked ? 'none' : '';
    });

    document.getElementById('wpsv-remove-file').addEventListener('click', reset);

    uploadBtn.addEventListener('click', function () {
        if (!selectedFile) { alert('Selecteer eerst een bestand.'); return; }
        doUpload();
    });

    document.getElementById('wpsv-copy-btn').addEventListener('click', function () {
        var inp = document.getElementById('wpsv-result-url');
        inp.select(); inp.setSelectionRange(0, 99999);
        document.execCommand('copy');
        this.textContent = '\u2713 Gekopieerd!';
        var btn = this;
        setTimeout(function () { btn.textContent = 'Kopi\u00ebren'; }, 2000);
    });

    document.getElementById('wpsv-upload-another').addEventListener('click', reset);

    document.addEventListener('click', function (e) {
        if (!e.target.classList.contains('wpsv-delete-btn')) return;
        if (!confirm(wpsv_admin.strings.confirm_delete)) return;
        var btn = e.target;
        var row = btn.closest('tr');
        var fd  = new FormData();
        fd.append('action',  'wpsv_delete');
        fd.append('nonce',   wpsv_admin.delete_nonce);
        fd.append('post_id', btn.dataset.postId);
        fetch(wpsv_admin.ajax_url, { method: 'POST', body: fd })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.success && row) row.remove();
                else alert(res.data ? res.data.message : 'Verwijderen mislukt.');
            });
    });

    function showFile(file) {
        var ext = file.name.split('.').pop().toLowerCase();
        if (ext !== 'step' && ext !== 'stp') { return showError('Alleen .step en .stp bestanden zijn toegestaan.'); }
        if (file.size > wpsv_admin.max_size_mb * 1024 * 1024) { return showError('Bestand is te groot (max ' + wpsv_admin.max_size_mb + ' MB).'); }
        selectedFile = file;
        hideAll();
        form.style.display = '';
        document.getElementById('wpsv-file-name').textContent = file.name;
        document.getElementById('wpsv-file-size').textContent = fmtBytes(file.size);
        document.getElementById('wpsv-model-title').value = file.name.replace(/\.[^/.]+$/, '');
    }

    function doUpload() {
        var fd = new FormData();
        fd.append('action',       'wpsv_upload');
        fd.append('nonce',        wpsv_admin.upload_nonce);
        fd.append('step_file',    selectedFile);
        fd.append('model_title',  document.getElementById('wpsv-model-title').value);
        fd.append('expire_days',  document.getElementById('wpsv-expire-days').value);
        fd.append('keep_forever', document.getElementById('wpsv-keep-forever').checked ? '1' : '');

        hideAll();
        progress.style.display = '';
        uploadBtn.disabled = true;

        var xhr = new XMLHttpRequest();
        xhr.open('POST', wpsv_admin.ajax_url);
        xhr.upload.addEventListener('progress', function (e) {
            if (!e.lengthComputable) return;
            var pct = Math.round(e.loaded / e.total * 100);
            document.getElementById('wpsv-progress-fill').style.width = pct + '%';
            document.getElementById('wpsv-progress-label').textContent = 'Uploaden: ' + pct + '%\u2026';
        });
        xhr.onload = function () {
            uploadBtn.disabled = false;
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success) {
                    hideAll();
                    result.style.display = '';
                    document.getElementById('wpsv-result-url').value = res.data.viewer_url;
                    document.getElementById('wpsv-open-viewer').href = res.data.viewer_url;
                    var notice = document.getElementById('wpsv-expiry-notice');
                    notice.textContent = res.data.expires
                        ? '\u23f1 Wordt automatisch verwijderd op ' + res.data.expires
                        : '\ud83d\udccc Permanent opgeslagen op de server.';
                } else {
                    showError(res.data ? res.data.message : 'Onbekende fout.');
                }
            } catch (ex) { showError('Upload mislukt. Probeer opnieuw.'); }
        };
        xhr.onerror = function () {
            uploadBtn.disabled = false;
            showError('Upload mislukt. Controleer je verbinding.');
        };
        xhr.send(fd);
    }

    function showError(msg) {
        hideAll();
        dropzone.style.display = '';
        errorBox.style.display = '';
        document.getElementById('wpsv-error-msg').textContent = msg;
    }

    function hideAll() {
        dropzone.style.display = 'none';
        form.style.display     = 'none';
        progress.style.display = 'none';
        result.style.display   = 'none';
        errorBox.style.display = 'none';
    }

    function reset() {
        selectedFile = null;
        fileInput.value = '';
        hideAll();
        dropzone.style.display = '';
    }

    function fmtBytes(b) {
        if (b >= 1048576) return (b / 1048576).toFixed(1) + ' MB';
        if (b >= 1024)    return (b / 1024).toFixed(0)    + ' KB';
        return b + ' B';
    }
}());
